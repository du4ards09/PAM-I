import { useState } from "react";
import { Image } from "react-native";
import { View, Text, Modal, Button, StyleSheet, TouchableOpacity } from "react-native";


export default function App() {

  const [modalVisible, setModalVisible] = useState(false);
  const [selecionarPlaneta, setSelecionarPlaneta] = useState();

  const abrirModal = (planetas) => {
    setSelecionarPlaneta(planetas);
    setModalVisible(true);
  };

  const fecharModal = () => {
    setModalVisible(false);

  };

  const planetas = [
    { nome: 'Sol',
    segundoNome: 'Estrela' ,
    imagem : require('./assets/1.png'),
    descricao: 'O Sol é a estrela central do Sistema Solar. Todos os outros corpos do Sistema Solar, como planetas, planetas anões,  asteroides, cometas e poeira, bem como todos os satélites associados a estes corpos, giram ao seu redor. ' ,
    caracteristicas: 'Sua enorme massa é formada por 73,4% de hidrogênio e 25,0% de gás hélio. ',
    },

    { nome: 'Mercúrio',
    segundoNome: 'Planeta' ,
    imagem : require('./assets/2.png'),
    descricao: 'Mercúrio é o menor e mais interno planeta do Sistema Solar, orbitando o Sol a cada 87,969 dias terrestres. A sua órbita tem a maior excentricidade e o seu eixo apresenta a menor inclinação em relação ao plano da órbita dentre todos os planetas do Sistema Solar.',
    caracteristicas: 'Mercúrio é o planeta mais próximo do Sol.',
    },

    { nome: 'Vênus',
    segundoNome: 'Planeta',
    imagem: require('./assets/3.png'),
    descricao: 'Vénus ou Vênus é o segundo planeta do Sistema Solar em ordem de distância a partir do Sol, orbitando-o a cada 224,7 dias. Recebeu seu nome em homenagem à deusa romana do amor e da beleza Vénus, equivalente a Afrodite.',
    caracteristicas:'como um planeta rochoso, sua superfície ser composta por vales e altas montanhas, cheias de vulcões.'
    },

    { nome: 'Terra',
    segundoNome: 'Planeta',
    imagem: require('./assets/4.png'),
    descricao: 'A Terra é o terceiro planeta mais próximo do Sol, o mais denso e o quinto maior dos oito planetas do Sistema Solar. É também o maior dos quatro planetas telúricos. É por vezes designada como Mundo ou Planeta Azul.',
    caracteristicas:'A Terra é considerada um planeta telúrico e possui sua estrutura interna dividida em: crosta terrestre, manto e núcleo.'
    },

    { nome: 'Marte',
    segundoNome: 'Planeta',
    imagem: require('./assets/5.png'),
    descricao: 'Marte é o quarto planeta a partir do Sol, o segundo menor do Sistema Solar. Batizado em homenagem a divindade romana da guerra, muitas vezes é descrito como o "Planeta Vermelho", porque o óxido de ferro predominante em sua superfície lhe dá uma aparência avermelhada. ',
    caracteristicas:'Marte é um planeta muito frio, árido e rochoso.'
    },

    { nome: 'Júpiter',
    segundoNome: 'Planeta',
    imagem: require('./assets/6.png'),
    descricao: 'Júpiter é o maior planeta do Sistema Solar, tanto em diâmetro quanto em massa, e é o quinto mais próximo do Sol. Possui menos de um milésimo da massa solar, contudo tem 2,5 vezes a massa de todos os outros planetas em conjunto. É um planeta gasoso, junto com Saturno, Urano e Netuno.',
    caracteristicas:'Júpiter é um planeta gasoso, composto predominantemente por hidrogênio e hélio, e possui um núcleo formado por elementos mais pesados.'
    },

    { nome: 'Saturno',
    segundoNome: 'Planeta',
    imagem: require('./assets/7.png'),
    descricao: 'Saturno é o sexto planeta a partir do Sol e o segundo maior do Sistema Solar atrás de Júpiter. Pertencente ao grupo dos gigantes gasosos, possui cerca de 95 massas terrestres e orbita a uma distância média de 9,5 unidades astronômicas.',
    caracteristicas:'Seu aspecto mais característico é seu brilhante sistema de anéis, o único visível da Terra.'
    },

    { nome: 'Urano',
    segundoNome: 'Planeta',
    imagem: require('./assets/8.png'),
    descricao: 'Urano é o sétimo planeta a partir do Sol, o terceiro maior e o quarto mais massivo dos oito planetas do Sistema Solar. Foi nomeado em homenagem ao deus grego do céu, Urano.',
    caracteristicas:'Urano é o sétimo planeta a partir do Sol e é o terceiro maior no sistema solar.'
    },

    { nome: 'Netuno',
    segundoNome: 'Planeta',
    imagem: require('./assets/9.png'),
    descricao: 'Netuno ou Neptuno é o oitavo planeta do Sistema Solar, o último a partir do Sol desde a reclassificação de Plutão para a categoria de planeta anão, em 2006. Pertencente ao grupo dos gigantes gasosos, possui um tamanho ligeiramente menor que o de Urano, mas maior massa, equivalente a 17 massas terrestres.',
    caracteristicas:'O planeta Netuno é composto, principalmente, de água muito quente, amônia e metano em seu núcleo, que tem aproximadamente o tamanho da Terra.'
    },


  ];

  const PlanetModal = ({ visible, fecharModal, planetas }) => {
    return (
      <Modal visible={visible} animationType="fade">

        <View style={styles.modal}>
            <Image style={{width:150,height:150}} source={planetas.imagem} />
            <Text style={styles.nomePlaneta}>{planetas.nome}</Text>
            <Text style={styles.segundoNome}>{planetas.segundoNome}</Text>
            <br />
            <Text style={styles.descricaoPlaneta}>{planetas.descricao}</Text>
            <Text style={styles.descricaoPlaneta}>{planetas.caracteristicas}</Text>
            <TouchableOpacity style={styles.touch} onPress={fecharModal}>
             <Text style={styles.touchText}>Voltar</Text>
            </TouchableOpacity>
          </View>
      </Modal>
  );
};
  
  return (
    <View style={styles.container}>
      {planetas.map((planetas, index) => (

        <TouchableOpacity key={index} style={styles.planetButton} onPress={() => abrirModal(planetas)}>
          <Text style={styles.planetButtonText}>{planetas.nome}</Text>
        </TouchableOpacity>

      ))}

      {selecionarPlaneta && (
        <PlanetModal visible={modalVisible} fecharModal={fecharModal} planetas={selecionarPlaneta} />
      )}
    </View>
  );

}

const styles = StyleSheet.create({
  container: {

    flex: 1,
    backgroundImage: `url('https://64.media.tumblr.com/d6d0246ca0dffa230f03be2521b3210f/tumblr_obfjz6Bd9f1runoqyo2_r1_540.gif')`,    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    //backgroundImage: 'linear-gradient(#000000,#191970	)',
    alignItems: 'center',
    justifyContent: 'center',
    
  },

  modal: {

    flex:1,
    alignItems: 'center',
    justifyContent: 'center',
    height: '200px',
    backgroundImage: `url('https://64.media.tumblr.com/d6d0246ca0dffa230f03be2521b3210f/tumblr_obfjz6Bd9f1runoqyo2_r1_540.gif')`,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',

  },


  planetButtonText: {

    width: 200,
    borderWidth: 2,
    borderRadius: 6,
    fontSize: '27px',
    textAlign: 'center',
    backgroundColor: '#363636',
    color: '#DCDCDC',
    marginBottom: '0.6pc',
    
  },

  segundoNome: {
    color: '#fff',
    marginBottom: 1,
  },

  descricaoPlaneta: {
    
    borderWidth: 1,
    borderRadius: 2,
    backgroundColor: 'black',
    fontWeight: 'bold',
    color: '#DCDCDC',
    marginLeft: 8,
    fontSize: '16.5px',
    marginBottom: '1pc',
    alignItems: 'center',
    justifyContent: 'center',

  },

  
  nomePlaneta: {

    fontSize: '30px',
    color: '#fff',
    alignItems: 'center',
    justifyContent: 'center',

  },

  touchText: {
    width: 200,
    borderWidth: 2,
    borderRadius: 6,
    fontSize: '27px',
    textAlign: 'center',
    backgroundColor: '#363636',
    color: '#DCDCDC',
  },

  touch: {
    position:'relative',
    marginTop: 20,
  },

});
